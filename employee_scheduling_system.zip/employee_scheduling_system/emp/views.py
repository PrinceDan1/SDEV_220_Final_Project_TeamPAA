from django.shortcuts import render, redirect
from .models import Employee, Events
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User, auth
from django.contrib.auth import login, logout

# Create your views here.

def allemployees(request):
    emp = Employee.objects.all()
    return  render(request, "emp/allemployees.html", {"allemployees":emp})

def singleemployee(request, empid):
    return  render(request, "emp/singleemployee.html")

def schedulingemployee(request):
    return render(request,  "emp/schedulingemployee.html")

@login_required
def addemployee(request):
    if request.method == "POST":
        #take all the parameters from the form. by their names kept
        employeeid = request.POST.get('employeeid')
        employeename = request.POST.get('employeename')
        employeeemail = request.POST.get('employeeemail')
        employeeaddress = request.POST.get('employeeaddress')
        employeephone = request.POST.get('employeephone')


        #create an object of the employee model.
        e = Employee()
        e.employeeid  = employeeid
        e.employeename = employeename
        e.email = employeeemail
        e.address = employeeaddress
        e.phone = employeephone

        e.save()

        return redirect("/allemployees")


    return render(request, "emp/addemployee.html")

@login_required
def attendance(request):
    return render(request, "emp/attendance.html")
    

def deleteemployee(request, empid):
    e = Employee.objects.get(pk = empid)
    e.delete()

    return redirect("allemployees")

@login_required
def updateemployee(request, empid):
    e = Employee.objects.get(pk = empid)
    
    #return redirect("allemployees")
    return render(request, "emp/updateemployee.html", {"singleemp" : e })
@login_required
def doupdateemployee(request, empid):
    updateemployeeid = request.POST.get("employeeid")
    updateemployeename = request.POST.get("employeename")
    updateemployeeemail = request.POST.get("employeeemail")
    updateemployeeadddress = request.POST.get("employeeaddress")
    updateemployeephone = request.POST.get("employeephone")

    emp = Employee.objects.get(pk = empid)
    emp.employeeid   = updateemployeeid
    emp.employeename = updateemployeename
    emp.email        = updateemployeeemail
    emp.address      = updateemployeeadddress
    emp.phone        = updateemployeephone

    emp.save()
    return redirect("allemployees")

@login_required
##Start of the employee scheduling
def index(request):  
    all_events = Events.objects.all()
    context = {
        "events":all_events,
    }
    return render(request,'emp/schedulingemployee.html',context)

def all_events(request):                                                                                                 
    all_events = Events.objects.all()                                                                                    
    out = []                                                                                                             
    for event in all_events:                                                                                             
        out.append({                                                                                                     
            'title': event.name,                                                                                         
            'id': event.id,                                                                                              
            'start': event.start.strftime("%m/%d/%Y, %H:%M:%S"),                                                         
            'end': event.end.strftime("%m/%d/%Y, %H:%M:%S"),                                                             
        })                                                                                                               
                                                                                                                      
    return JsonResponse(out, safe=False) 
 
def add_event(request):
    start = request.GET.get("start", None)
    end = request.GET.get("end", None)
    title = request.GET.get("title", None)
    event = Events(name=str(title), start=start, end=end)
    event.save()
    data = {}
    return JsonResponse(data)
 
def update(request):
    start = request.GET.get("start", None)
    end = request.GET.get("end", None)
    title = request.GET.get("title", None)
    id = request.GET.get("id", None)
    event = Events.objects.get(id=id)
    event.start = start
    event.end = end
    event.name = title
    event.save()
    data = {}
    return JsonResponse(data)
 
def remove(request):
    id = request.GET.get("id", None)
    event = Events.objects.get(id=id)
    event.delete()
    data = {}
    return JsonResponse(data)


