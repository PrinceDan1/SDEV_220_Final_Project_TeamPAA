from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def allemployees(request):
    return  render(request, "emp/allemployees.html")

def singleemployee(request, empid):
    return  render(request, "emp/singleemployee.html")

def schedulingemployee(request):
    return render(request,  "emp/schedulingemployee.html")

def addemployee(request):
    return render(request, "emp/addemployee.html")

def attendance(request):
    return render(request, "emp/attendance.html")
    